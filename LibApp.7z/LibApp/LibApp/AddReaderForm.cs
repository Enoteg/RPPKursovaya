﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace LibApp
{
    public partial class AddReaderForm : Form
    {
        private List<Reader> readers;
        private List<Hall> halls;

        public AddReaderForm(List<Reader> readers, List<Hall> halls)
        {
            InitializeComponent();
            this.readers = readers;
            this.halls = halls;
            PopulateHallsComboBox();
        }

        private void PopulateHallsComboBox()
        {
            hallsComboBox.Items.Clear();
            foreach (var hall in halls)
            {
                hallsComboBox.Items.Add(hall.Name);
            }
        }

        private void saveReaderButton_Click(object sender, EventArgs e)
        {
            try
            {
                Reader newReader = new Reader
                {
                    FIO = fioTextBox.Text,
                    PhoneNumber = phoneNumberTextBox.Text,
                    RegistrationDate = DateTime.Parse(registrationDateTextBox.Text),
                    DateOfBirth = DateTime.Parse(dateOfBirthTextBox.Text),
                    Education = educationTextBox.Text,
                    TicketNumber = GenerateTicketNumber(),
                    HallName = hallsComboBox.SelectedItem.ToString()
                };

                readers.Add(newReader);
                SaveReaders();
                MessageBox.Show("Читатель добавлен в библиотеку!");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Неправильный формат даты. Пожалуйста, введите дату в формате дд.мм.гггг.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GenerateTicketNumber()
        {
            return $"Ч-{readers.Count + 1:D4}";
        }

        private void SaveReaders()
        {
            string json = JsonConvert.SerializeObject(readers, Formatting.Indented);
            File.WriteAllText("readers.json", json);
        }
    }
}
