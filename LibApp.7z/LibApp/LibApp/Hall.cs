﻿using LibApp;
using System.Collections.Generic;

public class Hall
{
    public string Name { get; set; }
    public string LibraryName { get; set; }
    public string Specialization { get; set; }
    public int Capacity { get; set; }
    public int OccupiedSeats { get; private set; }
    public List<Reader> Readers { get; private set; }

    public Hall()
    {
        Readers = new List<Reader>();
    }

    public void AddReader(Reader reader)
    {
        if (!Readers.Contains(reader))
        {
            Readers.Add(reader);
            OccupiedSeats++;
        }
    }

    public void RemoveReader(Reader reader)
    {
        if (Readers.Contains(reader))
        {
            Readers.Remove(reader);
            OccupiedSeats--;
        }
    }
}
